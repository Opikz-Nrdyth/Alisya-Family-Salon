<div class="container-form-contact">
    <input type="text" name="name" placeholder="Your Name" class="input-contact">
    <input type="email" name="email" placeholder="Your Email" class="input-contact">
    <input type="phone" name="phone" placeholder="Your Phone" class="input-contact">
    <input type="subject" name="subject" placeholder="Your Subject" class="input-contact">
    <textarea name="message" name="message" cols="30" rows="10" placeholder="Your Message"
        class="textarea-contact"></textarea>
    <button class="btn-send"><i class="fa-solid fa-paper-plane"></i> Send</button>
</div>
<?php /**PATH /www/wwwroot/AlisyaSalon/resources/views/components/form-contact-me.blade.php ENDPATH**/ ?>