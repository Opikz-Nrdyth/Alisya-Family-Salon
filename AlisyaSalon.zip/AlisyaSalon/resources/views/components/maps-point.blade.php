<div>
    <div class="map-container">
        <div id="my-map-display"><iframe frameborder="0"
                src="https://www.google.com/maps/embed/v1/place?q={{ $query }}&key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8"></iframe>
        </div><a class="googlemaps-made" href="https://www.bootstrapskins.com/themes" id="auth-map-data">premium bootstrap
            themes</a>
    </div>
</div>
