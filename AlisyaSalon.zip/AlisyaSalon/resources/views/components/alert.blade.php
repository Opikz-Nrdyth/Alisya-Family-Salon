<div class="alert" id="alert">
    <button type="button" class="close">
        <span aria-hidden="true">×</span>
    </button>
</div>
