<div
    <?php echo e($attributes->class([
            'fi-ta-ctn divide-y divide-gray-200 overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-gray-950/5 dark:divide-white/10 dark:bg-gray-900 dark:ring-white/10',
        ])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\Bank Project_24\Alisya_Family_Salon\vendor\filament\tables\src\/../resources/views/components/container.blade.php ENDPATH**/ ?>