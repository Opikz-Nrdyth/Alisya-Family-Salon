<div class="container">
    <x-maps-point query="{{ $query }}" />
    <x-form-contact-me />
</div>
