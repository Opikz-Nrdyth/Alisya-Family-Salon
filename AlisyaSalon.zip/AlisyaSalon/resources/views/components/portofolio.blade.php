<div class="title-portofolio">
    <h2 class="title">portofolio</h2>
    <p>hasil karya by alisya family salon</p>

</div>
<div class="photos">
    <x-photo :portofolio="$portofolio" />
</div>
