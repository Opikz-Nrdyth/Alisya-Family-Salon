<div class="alert" id="alert">
    <button type="button" class="close">
        <span aria-hidden="true">×</span>
    </button>
</div>
<?php /**PATH D:\Bank Project_24\Alisya_Family_Salon\resources\views/components/alert.blade.php ENDPATH**/ ?>